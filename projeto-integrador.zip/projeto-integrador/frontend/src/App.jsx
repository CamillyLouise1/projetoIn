import React from "react";
import Table from "./components/Table";

const App = () => {
  return <Table />;
};

export default App;