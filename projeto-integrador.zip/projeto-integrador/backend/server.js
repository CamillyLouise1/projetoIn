import express from "express";
import conn from "./config/conn.js";
import { registrar, listar } from "./controllers/RegistrerController.js";
import dotenv from 'dotenv';



dotenv.config();


const app = express();
const PORT = 3333;

// Rotas
app.post("/registrar", registrar);
app.get("/registros", listar);

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});

