import conn from "../config/conn.js";

export function registrar(request, response) {
    const { cpf, data, data_inicio, data_termino, cronograma } = request.body;

    if (!cpf || !data || !data_inicio || !data_termino || !cronograma) {
        return response.status(400).json({ error: "Todos os campos são obrigatórios." });
    }

    const sql = `INSERT INTO registros (cpf, data, data_inicio, data_termino, cronograma) VALUES (?, ?, ?, ?, ?)`;
    run(sql, [cpf, data, data_inicio, data_termino, cronograma], function (err) {
        if (err) {
            console.error("Erro ao inserir registro:", err.message);
            response.status(500).json({ error: "Erro ao inserir registro." });
        } else {
            response.status(201).json({ message: "Registro cadastrado com sucesso!", id: this.lastID });
        }
    });
}

export function listar(request, response) {
    const sql = "SELECT * FROM registros";
    all(sql, [], (err, rows) => {
        if (err) {
            console.error("Erro ao buscar registros:", err.message);
            response.status(500).json({ error: "Erro ao buscar registros." });
        } else {
            response.json(rows);
        }
    });
}
